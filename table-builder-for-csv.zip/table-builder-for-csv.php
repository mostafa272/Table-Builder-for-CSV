<?php
/*
Plugin Name: Table Builder for CSV
Plugin URI: https://github.com/mostafa272/Table-Builder-for-CSV
Description: The Table Builder for CSV is a simple plugin that creates HTML table from csv file.
Version: 1.0
Author: Mostafa Shahiri<mostafa2134@gmail.com>
Author URI: https://github.com/mostafa272
*/
/*  Copyright 2009  Mostafa Shahiri(email : mostafa2134@gmail.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
add_action( 'wp_enqueue_scripts', 'tbfs_table_builder_for_CSV_scripts' );
add_action( 'get_footer', 'tbfs_table_builder_for_CSV_custom_scripts' );
/**
 * Add our JS and CSS files
 */
function tbfs_table_builder_for_CSV_scripts() {
  wp_enqueue_script( 'tablebuilderforcsv-script', plugins_url( 'js/script.js', __FILE__ ),array('jquery'),'1.0',false );
        wp_enqueue_style( 'tablebuilderforcsv-style', plugins_url( 'css/style.css', __FILE__ ) );

}
//set inline css and js code to add them to footer
function tbfs_table_builder_for_CSV_custom_scripts($listcsvtable) {
//global $listcsvtable;
if(!empty($listcsvtable))
{
$js="jQuery('document').ready(function(){
	pagination(".$listcsvtable['id'].",".$listcsvtable['rows'].");
})";
echo '<script type="text/javascript">'.$js.'</script>';
$csstyle="#csvtable".$listcsvtable['id']." td{
text-align:".$listcsvtable['textalign'].";
}
#csvtable".$listcsvtable['id']." tr:first-child  td{
background:".$listcsvtable['headerbg'].";
color:".$listcsvtable['headercolor'].";
}
#csvpagination".$listcsvtable['id']." a{
background:".$listcsvtable['pagebg'].";
color:".$listcsvtable['pagecolor'].";
}
#csvpagination".$listcsvtable['id']." a.active{
background:".$listcsvtable['pageactive'].";
}
#csvpagination".$listcsvtable['id']." a:hover{
background:".$listcsvtable['pagehoverbg'].";
color:".$listcsvtable['pagehovercolor'].";
}
#csvpagination".$listcsvtable['id']."{
text-align:".$listcsvtable['pagealign'].";}";
echo '<style type="text/css">'.$csstyle.'</style>';
}
}
//callback function of shortcode
function tbfs_table_builder_for_csv_makeshortcode($atts) {
//get attributes for shortcode
$a = shortcode_atts( array('src' => '', 'id'=>'1','captions'=>'','searchbox' => 'false','rows'=>'10', 'textalign'=>'center','headerbg'=>'#FF0000', 'headercolor'=>'#FFF','pagebg'=>'#FF0000', 'pagecolor'=>'#FFF','pageactive'=>'#008000','pagehoverbg'=>'#CCC','pagehovercolor'=>'#000','pagealign'=>'center'), $atts );
$up_dir=wp_upload_dir();
$fileurl=trailingslashit($up_dir['basedir']).sanitize_text_field($a['src']);
$filepath=wp_check_filetype($fileurl);
$a['id']=sanitize_text_field($a['id']);
$a['captions']=sanitize_text_field($a['captions']);
$a['searchbox']=sanitize_text_field($a['searchbox']);
$a['rows']=intval($a['rows']);
//set inline js and css values
$listcsvtable=array();
$listcsvtable['id']=$a['id'];
$listcsvtable['rows']=$a['rows'];
$listcsvtable['textalign']=sanitize_text_field($a['textalign']);
$listcsvtable['headerbg']=sanitize_text_field($a['headerbg']);
$listcsvtable['headercolor']=sanitize_text_field($a['headercolor']);
$listcsvtable['pagebg']=sanitize_text_field($a['pagebg']);
$listcsvtable['pagecolor']=sanitize_text_field($a['pagecolor']);
$listcsvtable['pageactive']=sanitize_text_field($a['pageactive']);
$listcsvtable['pagehoverbg']=sanitize_text_field($a['pagehoverbg']);
$listcsvtable['pagehovercolor']=sanitize_text_field($a['pagehovercolor']);
$listcsvtable['pagealign']=sanitize_text_field($a['pagealign']);
//add inline js and css code to footer
do_action( 'get_footer', $listcsvtable );
 if(!empty($a['captions']))
 {
 $caption=explode('@#',$a['captions']);
 }

 ob_start();
if($filepath['type']=='text/csv')
 {
  $file = fopen($fileurl,"r");
 if($a['searchbox']=='true')
 echo '<input type="text" id="csvlookup'.$listcsvtable['id'].'" class="csvlookup" onkeyup="lookuptable('.$listcsvtable['id'].','.$listcsvtable['rows'].')" placeholder="Search for ..."><br/>';
 echo '<table class="csvtable" id="csvtable'.$listcsvtable['id'].'">';
 //use custom captions
 if(!empty($a['captions']))
 {
  echo '<tr>';
   for($i=0;$i<count($caption);$i++)
  {
   echo '<td>'.$caption[$i].'</td>';
  }
   echo '</tr>';

 }
//read csv file
while($f=fgetcsv($file))
{
//displaying rows
echo '<tr>';
for($i=0;$i<count($f);$i++)
{
   echo '<td>'.$f[$i].'</td>';
}
echo '</tr>';
}
echo '</table>';
 echo	'<div id="csvpagination'.$listcsvtable['id'].'" class="csvpagination"></div>';
fclose($file);
}
 return ob_get_clean();
}
//add shortcode
add_shortcode('table_builder_for_csv','tbfs_table_builder_for_csv_makeshortcode');